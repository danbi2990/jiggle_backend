module.exports = {
  google: {
    clientID:
      "935076889544-04jjfc891ftkkjrsddrva9glretarji6.apps.googleusercontent.com",
    clientSecret: "uY3LGeDEwAJSfHDf5k41zRqU",
    callbackURL: "http://localhost:3000/auth/google/callback"
  },
  mongo_uri: "mongodb://localhost:27017/jiggle",
  mongo_options: { useMongoClient: true },
  cookieKey: "matdolmatdolmatdol",
  padding: "                                                  "
};
